const { append } = require('express/lib/response');
const User = require('../models/User')
const Item = require('../models/User')

exports.home = function(req, res){
    res.render('pages/home');
};

exports.newUserForm = function(req, res){
    res.render('pages/user_new');
};

exports.newUserUso = function(req,res){
    res.render('pages/usuario');
}

exports.newUserlog = function(req, res){ 
    res.render('pages/logado');
};

exports.newUserins = function(req, res){ 
    res.render('pages/main');
};

exports.newUserPiz = function(req,res){
    res.render('pages/pizzaria');
}

exports.saveUser = function (req, res) {//salvar usuário
    const dados = req.body;
    const dadosFormatados = {
        username: dados.inputusername,
        email: dados.inputemail,
        password: dados.inputpassword
    }
    console.log(dadosFormatados);
    let user = new User(dadosFormatados);
    user.create();
    res.redirect('/log') // após salvar os dados, vai ser redirecionado para a página do restaurante
;}
exports.saveItem = function (req, res) {//salvar usuário
    const dados = req.body;
    const dadosFormatados = {
        nome: dados.inputnome,
        valor: dados.inputvalor,

    }
    console.log(dadosFormatados);
    console.log(" dados recebidos no controlador");
    let item = new Item(dadosFormatados);
    item.create();
    res.redirect('/log') // após salvar os dados, vai ser redirecionado para a página do restaurante
;}
