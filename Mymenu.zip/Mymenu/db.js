const { Pool } = require('pg')

const pool = new Pool({
    user: 'tykfqvdt',
    host: 'motty.db.elephantsql.com', 
    database:'tykfqvdt', 
    password: '32zg1O6csWH5VQYOQYfNOd2zaG2ilgkF', 
    port: 5432,  //padrão 
})

module.exports = pool