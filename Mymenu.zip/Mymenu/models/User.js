const validator = require("validator");
const pool = require('../db')


let User = function(data) {
    this.data = data;
    this.errors = [];
};

let Item= function(data){
    this.data = data;
    this.errors = [];
};

User.prototype.validate = function(){
    if (this.data.username == ""){
        this.errors.push("username em branco");
    }
    if (this.data.email == ""){
        this.errors.push("email em branco");
    }
    if (this.data.password == ""){
        this.errors.push("password em branco");
    } else{
        if(!validator.isAlphanumeric(this.data.password)){
            this.errors.push("password deve ser em alfa numerico");
        }
    }
};

Item.prototype.validate = function(){
    if(this.data.nome == ""){
        this.errors.push("nome em branco");
    }
    if(this.data.valor==""){
        this.errors.push("sem valor");
    }
}

Item.prototype.create = function() {
    const cons = 'INSERT INTO itens(nome,valor) values($1, $2)'
    conValues = [this.data.nome, this.data.valor];
    return new Promise((resolve, reject)=>{
        this.validate()
        if(this.errors.length >0){
            reject(this.errors)
        }else{
            pool.query(cons, conValues,(error, results)=>{
                if(error){
                    reject("erro ao cadastrar item")
                }else{
                    resolve("item cadastrado com sucesso")
                }
            });
        }
    })
};
User.prototype.create = function() {
    const con = 'INSERT INTO users(username,email,password) values($1, $2, $3)'
    conValues = [this.data.username, this.data.email, this.data.password];
    return new Promise((resolve, reject)=>{
        this.validate()
        if(this.errors.length >0){
            reject(this.errors)
        }else{
            pool.query(con, conValues,(error, results)=>{
                if(error){
                    reject("erro ao criar o usuario")
                }else{
                    resolve("usuario criado com sucesso")
                }
            });
        }
    })
};

module.exports = User;
module.exports = Item;