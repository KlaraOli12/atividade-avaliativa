const express = require('express')
const router = express.Router()
const userController = require('./controllers/userController');

router.get("/", userController.home);

router.get("/usuario", userController.newUserUso);

router.get("/form", userController.newUserForm);

router.get("/ins", userController.newUserins);

router.get("/log", userController.newUserlog);

router.get("/piz", userController.newUserPiz);

router.post("/save_item", userController.saveItem);

router.post("/save_user", userController.saveUser);

module.exports = router